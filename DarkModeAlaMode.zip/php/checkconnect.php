<?php
  
  $user='shypefx';
  $password='Javachteam';
  $basededonnees='shypefx_bdd';

  $conn = mysqli_connect('mysql-shypefx.alwaysdata.net', $user, $password, $basededonnees);
    
  // Check connection

  session_start();
  if($conn === false){
      die("ERROR: Could not connect. " 
          . mysqli_connect_error());
  }
    
  // Taking all 5 values from the form data(input)
  $email =  $_REQUEST['email'];
  $passeword = $_REQUEST['psw'];
    
  // Performing insert query execution
  // here our table name is college
  $query = "SELECT * FROM Users where email = '$email' and passeword ='$password'";
    
    $result = mysql_query($query) or die(mysql_error());
    $count = mysql_num_rows($result);  

    if ($count == 1){
        $_SESSION['email'] = $email;
        header("http://shypefx.alwaysdata.net/html/compte_connect.html"); //header to redirect, but doesnt work
        }else{
        //3.1.3 If the login credentials doesn't match, he will be shown with an error message.
        echo "Invalid Login Credentials.";
        }
        } 
    
  // Close connection
  mysqli_close($conn);
  ?>